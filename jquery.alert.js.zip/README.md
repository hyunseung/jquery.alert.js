# jQuery.alert.js

jQuery alert Plugin
이 플러그인은 브라우저 시스템 알림창을 조금 더 아릅답게 화면에 표시하고 다양한 브라우져에서 동일하게 표시 하기 위한 플러그인입니다.

기본 jQuery가 설치되어있어야 하며 3가지(Alert,Confirm,Prompt)의 기능을 제공합니다.